var data = require('./data');

function print(element, index, array) {
  console.log(element)
}

data.answers.forEach(print);
